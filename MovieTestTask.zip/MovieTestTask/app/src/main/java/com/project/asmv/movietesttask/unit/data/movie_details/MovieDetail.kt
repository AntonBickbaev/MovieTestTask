package com.project.asmv.movietesttask.unit.data.movie_details

data class MovieDetail(
    var id: Long?,
    var posterPath: String?,
    var title: String?,
    var overview: String?
)