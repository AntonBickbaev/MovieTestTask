package com.project.asmv.movietesttask.unit.data.movie_list

data class PopularMovieItem(
    var id: Long?,
    var posterPath: String?,
    var title: String?
)