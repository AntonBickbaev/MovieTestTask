package com.project.asmv.movietesttask.unit.base

interface BaseView {
    fun disposble()
}